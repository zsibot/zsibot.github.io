
#include "sdk/motor_function.h"
#include <iostream>
#include <thread>
using namespace mc_sdk;
int main() {

  float init_q_abad[4];
  float init_q_hip[4];
  float init_q_kneep[4];

  float default_abad_pos = 0.0;
  float default_hip_pos = 1.4;
  float default_knee_pos = -2.4;

  constexpr int CLIENT_PORT = 43988;   // local port
  std::string CLIENT_IP = "127.0.0.1"; // local IP address
  std::string DOG_IP = "127.0.0.1";    // dog ip

  // 创建connector

  MotorFunc motor_func;
  motorCmd cmd;
  motor_func.initRobot(CLIENT_IP, CLIENT_PORT,
                       DOG_IP); //创建连接, DOG_IP 默认 192.168.234.1，
                                //需要修改时需手动传入DOG_IP

  while (1) {
    //获取机器狗数据
    auto state = motor_func.getMotorState();
    if (motor_func.haveMotorData()) {
      static bool first_triger = false;
      if (!first_triger) {
        first_triger = true;
        for (size_t i = 0; i < 4; i++) {
          init_q_abad[i] = state->q_abad[i];
          init_q_hip[i] = state->q_hip[i];
          init_q_kneep[i] = state->q_knee[i];
        }
      }

      static double stage1_progress = 0.0;
      static double stage2_progress = 0.0;
      static int stage = 0;
      stage1_progress += 0.002;
      double duration = 2.0;
      double ratio = stage1_progress / duration;
      if (ratio > 1.0) {
        ratio = 1.0;
        stage = 1;
      }

      if (stage == 1) {
        default_abad_pos = 0.0;
        default_hip_pos = 0.8;
        default_knee_pos = -1.5;
        stage2_progress += 0.002;
        ratio = stage2_progress / duration;
        if (ratio > 1.0) {
          ratio = 1.0;
        }

        static bool stage2_start = false;

        if (!stage2_start) {
          stage2_start = true;
          for (size_t i = 0; i < 4; i++) {
            init_q_abad[i] = state->q_abad[i];
            init_q_hip[i] = state->q_hip[i];
            init_q_kneep[i] = state->q_knee[i];
          }
        }
      }

      for (size_t i = 0; i < 4; i++) {
        cmd.q_des_abad[i] =
            ratio * default_abad_pos + (1.0 - ratio) * init_q_abad[i];
        cmd.q_des_hip[i] =
            ratio * default_hip_pos + (1.0 - ratio) * init_q_hip[i];
        cmd.q_des_knee[i] =
            ratio * default_knee_pos + (1.0 - ratio) * init_q_kneep[i];
        // std::cout << "q_a: " << cmd.q_des_abad[i]
        //           << " q_h: " << cmd.q_des_hip[i]
        //           << " q_k: " << cmd.q_des_knee[i] << " leg: " << i
        //           << std::endl;
        cmd.kp_abad[i] = 80;
        cmd.kp_hip[i] = 80;
        cmd.kp_knee[i] = 80;
        cmd.kd_abad[i] = 1;
        cmd.kd_hip[i] = 1;
        cmd.kd_knee[i] = 1;
      }
      //发布关节命令
      int ret = motor_func.sendMotorCmd(cmd);
      if (ret < 0) {
        std::cout << "send cmd error" << std::endl;
      }
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }

  return 0;
}