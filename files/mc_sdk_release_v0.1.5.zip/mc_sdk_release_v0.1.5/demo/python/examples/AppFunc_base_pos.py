import mc_sdk_py
import time

app=mc_sdk_py.AppFunc()
app.init_robot("127.0.0.1",43988, "127.0.0.1") #local_ip, local_port, dog_ip
app.stand_up()
time.sleep(4)
app.lie_down()
time.sleep(4)
app.stand_up()
time.sleep(4)
app.jump()
time.sleep(4)
app.front_jump()
time.sleep(4)
app.backward_jump()
time.sleep(4)
app.backflip()
time.sleep(4)
app.attitude_control(0.1,0.1,0.1,0.1)
time.sleep(4)
app.stand_up()
while True:
    # app.backflip()
    time.sleep(2)