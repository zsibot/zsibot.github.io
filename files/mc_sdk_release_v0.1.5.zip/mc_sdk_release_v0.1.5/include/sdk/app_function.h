#pragma once
#include <memory>
#include <mutex>
#include <string>
namespace mc_sdk {
class AppFunc {
private:
  struct highLevelFunc;
  std::shared_ptr<highLevelFunc> impl_;
  std::mutex cmd_mutex_;
  int safeCheck();

public:
  AppFunc();
  ~AppFunc();
  void initRobot(const std::string &local_ip, const int local_port, const std::string& dog_ip = "192.168.234.1");
  int standUp();
  int lieDown();
  int passive();
  int move(const float vx, const float vy, const float yaw_rate);

  int jump();
  int frontJump();
  int backwardJump();
  int backflip();
  int attitudeControl(const float yaw_vel, const float roll_vel,
                      const float pitch_vel, const float height_vel);

  float getRoll();
  float getPitch();
  float getYaw();
  float getBodyAccX();
  float getBodyAccY();
  float getBodyAccZ();
  float getBodyGyroX();
  float getBodyGyroY();
  float getBodyGyroZ();
  float getPosWorldX();
  float getPosWorldY();
  float getPosWorldZ();
  float getWorldVelX();
  float getWorldVelY();
  float getWorldVelZ();
  uint32_t getBatteryPower();
};

} // namespace mc_sdk
